Just easySpace!

Simple, stupid solar system model) 
