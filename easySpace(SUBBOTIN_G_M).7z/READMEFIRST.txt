Все изображения можно скачать с github, без них программа не работает!
https://github.com/Yaromir-Svetozarovich/easySpace
